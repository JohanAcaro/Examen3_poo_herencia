package com.segundo;

import com.base.Hija;
import com.base.Padre;
import com.primero.Alumno;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Alumno alumno1 = new Alumno(1,"juan l�pez",4.85f);//instanciar clase
		Alumno alumno2 = new Alumno(2,"mar�a p�rez",7.85f);
		Alumno alumno3 = new Alumno(3,"luis s�nchez",5.85f);
		//insert : NO es persistencia de datos : NO se almacena en una tabla de una base de datos
	
		//consultar la calificaci�n del alumno2
		float notaAlumno2 = alumno2.getCalificacion();
		//mostrar la nota del Alumno2
		//consola. system out
		//aplicaci�n de escritorio : swing
		//aplicaci�n web : p�ginas web din�micas : jsp
		System.out.println("la nota del alumno 2 es "+notaAlumno2);
		
		//Padre padre=new Padre();
		Hija hija=new Hija();
		hija.saludar("Mar�a","Madrid");
	}
	
	
	
	
	
}
