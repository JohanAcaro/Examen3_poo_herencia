package com.base;

public abstract class Padre {//clase abstracta NO puede ser instanciada
//sobrecarga de m�todos
//en java, la sobrecarga NO es un tipo de retorno
	
	//m�todo con retorno String
	public String saludar(String nombre) {
		return "hola "+nombre;
	}
	
	//m�todo sin retorno
	public void saludar(String nombre,String ciudad) {
		System.out.println("hola "+nombre+" en "+ciudad);
	}
	
}//cierra clase
